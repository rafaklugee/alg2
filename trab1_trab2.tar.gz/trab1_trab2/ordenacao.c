#include "ordenacao.h"
#include "pilha.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>

void getNome(char nome[]) {
    strncpy(nome, "Rafael Ribeiro Kluge", MAX_CHAR);
    nome[MAX_CHAR - 1] = '\0';
}

uint32_t getGRR() { return 20244439; }

ssize_t buscaSequencial(int vetor[], size_t tam, int valor,
                        uint64_t* numComparacoes) {
    int i;
    for (i = tam-1; i >= 0; i--) {
        if (vetor[i] < valor)
            return i + 1;
    }
    return i;
}

ssize_t buscaSequencialRec(int vetor[], size_t tam, int valor,
                           uint64_t* numComparacoes) {
        if (tam == 0) {
            return -1;
        }
        if (vetor[tam-1] <= valor) {
            return tam - 1;
        }
        return buscaSequencialRec(vetor, tam-1, valor, numComparacoes);
}

ssize_t buscaBinaria(int vetor[], size_t tam, int valor,
                     uint64_t* numComparacoes) {
        ssize_t inicio = 0;
        ssize_t fim = tam - 1;
        while (inicio <= fim) {
            (*numComparacoes)++;
            ssize_t meio = (inicio + fim)/2;
            if (vetor[meio] == valor)
                return meio;

            if (vetor[meio] > valor)
                fim = meio - 1;

            if (vetor[meio] < valor)
                inicio = meio + 1;
        }   
    return inicio;
}

uint64_t auxiliarbuscabin (int vetor[], ssize_t inicio, ssize_t fim, int valor, uint64_t* numComparacoes) {
    while (inicio <= fim) {
        ssize_t meio = (inicio + fim)/2;
        if (vetor[meio] == valor)
            return meio;

        if (vetor[meio] > valor)
            return auxiliarbuscabin (vetor, inicio, meio - 1, valor, numComparacoes);

        if (vetor[meio] < valor)
            return auxiliarbuscabin (vetor, meio + 1, fim, valor, numComparacoes);
    }
    return inicio;
}

ssize_t buscaBinariaRec(int vetor[], size_t tam, int valor,
                        uint64_t* numComparacoes) {
        return auxiliarbuscabin (vetor, 0, tam - 1, valor, numComparacoes);
}

uint64_t insertionSort(int vetor[], size_t tam) {
    size_t i, j;                                    
    for (i = 0; i < tam - 1; i++) {
        j = i;
        while ((j > 0) && vetor[j] < vetor[j - 1]) {
                troca (vetor, j, j - 1);
                j--;
        }
    }
    return 0;
}

uint64_t auxiliarinssortrec (int vetor[], int fim, size_t tam, uint64_t *numcomp) {
    int j = fim, temp = vetor[j];
    if (fim >= tam) {
        return 0;
    }
    while (j > 0 && temp < vetor[j - 1]) {
        vetor[j] = vetor[j - 1];
        j--;
    }
    vetor[j] = temp;
    return auxiliarinssortrec (vetor, fim + 1, tam, numcomp);
    
}

uint64_t insertionSortRec(int vetor[], size_t tam) {
    uint64_t numcompaux = 0;
    return auxiliarinssortrec (vetor, 1, tam, &numcompaux);
}

uint64_t selectionSort(int vetor[], size_t tam) { 
    int i, j, idxmenor, temp;
    for (i = 0; i < tam - 1; i++) {
        idxmenor = i;
        for (j = i + 1; j < tam; j++) {
            if (vetor[idxmenor] > vetor[j])
                idxmenor = j;
        }
        if (i != idxmenor) {
            temp = vetor[i];
            vetor[i] = vetor[idxmenor];                
            vetor[idxmenor] = temp;
            }
        }
        return 0;
}

uint64_t auxiliarselecsortrec (int vetor[], int inicio, size_t tam, uint64_t *numcomp) {
    int i, temp, idxmenor = inicio;                               
    if (inicio >= tam - 1) {                              
        return 0;
    }
    for (i = inicio + 1; i < tam; i++) {
        if (vetor[i] < vetor[idxmenor])
            idxmenor = i;
    }
        temp = vetor[inicio];
        vetor[inicio] = vetor[idxmenor];
        vetor[idxmenor] = temp;

    return auxiliarselecsortrec (vetor, inicio + 1, tam, numcomp);
}

uint64_t selectionSortRec(int vetor[], size_t tam) {
    uint64_t numcompaux = 0;
    return auxiliarselecsortrec (vetor, 0, tam, &numcompaux);
}

uint64_t merge (int vetor[], int inicio, int meio, int fim, uint64_t *numcomp) {
    int i, j, inicio1 = inicio, inicio2 = meio + 1, fim1 = meio, fim2 = fim; 
    int tamaux = (fim - inicio) + 1;

    int* vaux = (int*)malloc(tamaux * sizeof(int));

    if (vaux != NULL) {
        for (i = 0; i < tamaux; i++) {
            if (inicio1 <= fim1 && inicio2 <= fim2) {
                if (vetor[inicio1] < vetor[inicio2]) {
                    vaux[i] = vetor[inicio1];
                    inicio1++;
                }
                else {
                    vaux[i] = vetor[inicio2];
                    inicio2++;
                }
            }
            else {
                if (inicio1 <= meio) {
                    vaux[i] = vetor[inicio1];
                    inicio1++;
                }
                else {
                    vaux[i] = vetor[inicio2];
                    inicio2++;
                }
            }
        }
        for (j = 0; j < tamaux; j++) {
            vetor[inicio] = vaux[j];
            inicio++;
        }
    }
    free (vaux);
    return 0;
}

uint64_t auxiliarmergesort (int vetor[], int inicio, int fim, uint64_t *numcomp) {
    int meio;
    if (inicio < fim) {
        meio = (inicio + fim)/2;
        auxiliarmergesort (vetor, inicio, meio, numcomp);
        auxiliarmergesort (vetor, meio + 1, fim, numcomp);
        merge (vetor, inicio, meio, fim, numcomp);
    }
    return 0;
}

uint64_t mergeSortRec (int vetor[], size_t tam) {
    uint64_t numcomp = 0;
    return auxiliarmergesort (vetor, 0, tam - 1, &numcomp);
}

uint64_t mergeSort (int vetor[], size_t tam) {
    uint64_t numcomp = 0;
    auxiliarmergesort (vetor, 0, tam - 1, &numcomp);
    return 0;
}

uint64_t mergeSortSR (int vetor[], size_t tam) {
    uint64_t numcompaux = 0;
    int esq;

    for (esq = 1; esq < tam; esq = 2 * esq) {
        int i;
        for (i = 0; i < tam - esq; i += 2 * esq) {
            int esquerda = i;
            int meio = i + esq - 1;
            int direita;
            if (i + 2 * esq - 1 < tam)
                direita = i + 2 * esq - 1;
            else
                direita = tam - 1;

            merge(vetor, esquerda, meio, direita, &numcompaux);
        }
    }

    return 0;
}


uint64_t particionar (int vetor[], int inicio, int fim, uint64_t *numcomppart) {
    size_t i;
    int x = vetor[fim];
    size_t m = inicio;
        for (i = inicio; i < fim; i++) {
            if (vetor[i] <= x) {
                troca (vetor, m, i);
                m++;
            }
        }
    troca (vetor, m, fim);
    return m;
}

uint64_t quickSortAux (int vetor[], int inicio, int fim, uint64_t *numcompaux) {
    if (inicio >= fim)
        return 0;
    size_t m = particionar (vetor, inicio, fim, numcompaux);
    quickSortAux (vetor, inicio, m-1, numcompaux);
    quickSortAux (vetor, m+1, fim, numcompaux);

    return 0;
}

uint64_t quickSort(int vetor[], size_t tam) {
    uint64_t numcompquick = 0;
        return quickSortAux (vetor, 0, tam - 1, &numcompquick);
}

uint64_t max_heapify (int vetor[], int i, size_t tam, uint64_t *numcompheapify) {
    int maior = i;

    size_t esquerda = 2*i+1;
    size_t direita = 2*i+2;

    if (esquerda <= tam) {
        if (vetor[esquerda] > vetor[maior])
        maior = esquerda;
    }
    
    if (direita <= tam) {
        if (vetor[direita] > vetor[maior])
        maior = direita;
    }

    if (maior != i) {
        troca (vetor, i, maior);
        max_heapify (vetor, maior, tam, numcompheapify);
    }
    return 0;
}

uint64_t max_heapifySR (int vetor[], int i, size_t tam, uint64_t *numcompheapify) {
    int maior = i;

    size_t esquerda;
    size_t direita;

    while (1) {
        esquerda = 2*i+1;
        direita = 2*i+2;
        
        if (esquerda <= tam) {
            if (vetor[esquerda] > vetor[maior])
            maior = esquerda;
        }
        
        if (direita <= tam) {
            if (vetor[direita] > vetor[maior])
            maior = direita;
        }

        if (maior != i) {
            troca (vetor, i, maior);
            i = maior;
        }
        else
            break;
    }
    return 0;
}

uint64_t heapSortSR (int vetor[], size_t tam) {
    int i;
    uint64_t numcompheap = 0;
    construir_max_heapSR (vetor, tam, &numcompheap);
    for (i = tam - 1; i > 0; i--) {
        troca (vetor, 0, i);
        max_heapifySR (vetor, 0, i-1, &numcompheap);
    }
    return 0;
}

uint64_t construir_max_heap (int vetor[], size_t tam, uint64_t *numcompcons) {
    int i;
    for (i = tam/2 - 1; i >= 0; i--)
        max_heapify (vetor, i, tam - 1, numcompcons);
    return 0;
}

uint64_t construir_max_heapSR (int vetor[], size_t tam, uint64_t *numcompcons) {
    int i;
    for (i = tam/2 - 1; i >= 0; i--)
        max_heapifySR (vetor, i, tam - 1, numcompcons);
    return 0;
}

uint64_t heapSort(int vetor[], size_t tam) {
    int i;
    uint64_t numcompheap = 0;
    construir_max_heap (vetor, tam, &numcompheap);
    for (i = tam - 1; i > 0; i--) {
        troca (vetor, 0, i);
        max_heapify (vetor, 0, i-1, &numcompheap);
    }
    return 0;
}

uint64_t quickSortAuxSR (int vetor[], int inicio, int fim, uint64_t *numcompquickSR) {
    size_t m;
    TPilha *p = malloc(sizeof(TPilha));
    pilha_inicio(p);

    if (p == NULL) {
        printf ("\nErro ao alocar memória!");
        return 0;
    }

    empilhar (p, inicio);
    empilhar (p, fim);
    while (!pilha_vazia(p)) {
        fim = desempilhar (p);
        inicio = desempilhar (p);
        if (inicio < fim) {
            m = particionar (vetor, inicio, fim, numcompquickSR);
            empilhar (p, inicio);
            empilhar (p, m - 1);
            empilhar (p, m + 1);
            empilhar (p, fim);
        }
    }

    free(p);
    return 0;
}

uint64_t quickSortSR(int vetor[], size_t tam) {
    uint64_t numcompquickSR = 0;
        quickSortAuxSR (vetor, 0, tam - 1, &numcompquickSR);
    return 0;
}

void menu () {
    printf ("\nDas ordenacoes:\n");
    printf ("(1) Busca Sequencial iterativa\n");
    printf ("(2) Busca sequencial recursiva\n");
    printf ("(3) Busca Binaria iterativa\n");
    printf ("(4) Busca Binaria recursiva\n");
    printf ("(5) Insertion Sort iterativo\n");
    printf ("(6) Insertion Sort recursivo\n");
    printf ("(7) Selection Sort iterativo\n");
    printf ("(8) Selection Sort recursivo\n");
    printf ("(9) Merge Sort recursivo\n");

    printf ("(10) MergeSort Recursivo\n");
    printf ("(11) QuickSort Recursivo\n");
    printf ("(12) HeapSort Recursivo\n");
    printf ("(13) MergeSort Sem Recursao\n");
    printf ("(14) QuickSort Sem Recursao\n");
    printf ("(15) HeapSort Sem Recursao\n");
    printf ("(0) Sair do programa\n");
    printf ("Escolha uma opcao: ");
}

void mostravetor (int vetor[], size_t tam) {
    int i;
    printf ("O vetor eh:\t");
    for (i = 0; i < tam; i++) {
        printf ("%d\t", vetor[i]);
    }
}

void troca (int vetor[], size_t i, size_t m) {
    size_t temp;
    temp = vetor[i];
    vetor[i] = vetor[m];
    vetor[m] = temp;
}