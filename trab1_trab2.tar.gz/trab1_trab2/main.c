#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "ordenacao.h"

int main() {
    char nome[MAX_CHAR];
    int escolha;
    uint64_t numComp = 0;

    // Inserir o tamanho do vetor que se quer testar:
    int64_t tamVetor = 100;                            
    int* vetor = (int*)malloc(tamVetor * sizeof(int));    


    if (vetor == NULL) {
        printf("Erro ao alocar memória!");
        return 1;
    }

    // Gerando vetor randômico
    //srand(time(NULL));
    //for (size_t i = 0; i < tamVetor; i++)
    //    vetor[i] = rand() % 100;

    // Gerando vetor inteiramente decrescente
    for (size_t i = 0; i < tamVetor; i++)
        vetor[i] = tamVetor - i;

    getNome(nome);
    printf("Trabalho de %s\n", nome);
    printf("GRR %u\n", getGRR());

    printf ("Voce esta testando um vetor de %ld posicoes!\n", tamVetor);

        menu();
        scanf ("%d", &escolha);
    
        switch(escolha) {
            case 0:
            // Saindo do programa
            printf ("\nVoce optou por sair do programa.\n");
            free(vetor);
            return 0;

            case 1:
            // Fazendo testes pela Busca Sequencial Iterativa:
            int valorbuscaseq;
            printf ("Digite o valor: ");
            scanf ("%d", &valorbuscaseq);            
            buscaSequencial (vetor, tamVetor, valorbuscaseq, &numComp);
            printf ("\nBusca Sequencial Iterativa\n");
            break;
            // Fim da Busca Sequencial Iterativa.

            case 2:
            // Fazendo testes pela Busca Sequencial Recursiva:
            int valorbuscaseqrec;
            printf ("Digite o valor: ");
            scanf ("%d", &valorbuscaseqrec);           
            buscaSequencialRec (vetor, tamVetor, valorbuscaseqrec, &numComp);
            printf ("\nBusca Sequencial Recursiva\n");
            break;
            // Fim da Busca Sequencial Recursiva.

            case 3:
            // Fazendo testes pela Busca Binária Iterativa:
            int valorbuscabin;
            printf ("Digite o valor: ");
            scanf ("%d", &valorbuscabin);     
            buscaBinaria (vetor, tamVetor, valorbuscabin, &numComp);
            printf ("\nBusca Binária Iterativa\n");
            break;
            // Fim da Busca Binária Iterativa.

            case 4:
            // Fazendo testes pela Busca Binária Recursiva
            int valorbuscabinrec;
            printf ("Digite o valor: ");
            scanf ("%d", &valorbuscabinrec);       
            buscaBinariaRec (vetor, tamVetor, valorbuscabinrec, &numComp);
            printf ("\nBusca Binária Recursiva\n");
            break;
            // Fim da Busca Binária Recursiva.

            case 5:
            // Fazendo teste pelo Insertion Sort Iterativo:           
            insertionSort (vetor, tamVetor);
            printf ("\nInsertion Sort Iterativo\n");
            break;
            // Fim do Insertion Sort Iterativo.

            case 6:
            // Fazendo teste pelo Insertion Sort Recursivo:            
            insertionSortRec (vetor, tamVetor);
            printf ("\nInsertion Sort Recursivo\n");
            break;
            // Fim do Insertion Sort Recursivo.

            case 7:
            // Fazendo teste pelo Selection Sort Iterativo:           
            selectionSort (vetor, tamVetor);
            printf ("\nSelection Sort Iterativo\n");
            break;
            // Fim do Selection Sort Iterativo.

            case 8:
            // Fazendo teste pelo Selection Sort Recursivo:        
            selectionSortRec (vetor, tamVetor);
            printf ("\nSelection Sort Recursivo\n");
            break;
            // Fim do Selection Sort Recursivo.

            case 9:
            // Fazendo teste pelo Merge Sort Recursivo:
            
            mergeSortRec (vetor, tamVetor);

            printf ("\nMerge Sort Recursivo\n");
            break;
            // Fim do Merge Sort Recursivo.

            case 10:
            // Fazendo testes para o MergeSort Recursivo
            mergeSort (vetor, tamVetor);
            printf ("\nMergeSort Recursivo\n");
            break;
            // Fim do MergeSort Recursivo

            case 11:
            // Fazendo testes para o QuickSort Recursivo
            quickSort (vetor, tamVetor);
            printf ("\nQuickSort Recursivo\n");
            break;
            // Fim do QuickSort Recursivo

            case 12:
            // Fazendo testes para o HeapSort Recursivo
            heapSort (vetor, tamVetor);
            printf ("\nHeapSort Recursivo\n");
            break;
            // Fim do HeapSort Recursivo

            case 13:
            // Fazendo testes para o MergeSort Sem Recursao
            mergeSortSR (vetor, tamVetor);
            printf ("\nMergeSort Sem Recursao\n");
            break;
            // Fim do MergeSort Sem Recursao

            case 14:
            // Fazendo testes para o QuickSort Sem Recursao
            quickSortSR (vetor, tamVetor);
            printf ("\nQuickSort Sem Recursao\n");
            break;
            // Fim do QuickSort Sem Recursao

            case 15:
            // Fazendo testes para o HeapSort Sem Recursao
            heapSortSR (vetor, tamVetor);
            printf ("\nHeapSort Sem Recursao\n");
            break;
            // Fim do HeapSort Sem Recursao

            default:
                printf ("\nEscolha inválida!\n");
                break;
        }
            mostravetor (vetor, tamVetor);
            printf ("\n");

    free (vetor);
    return 0;
}