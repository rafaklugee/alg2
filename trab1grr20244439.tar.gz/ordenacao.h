#ifndef ORDENACAO_H_
#define ORDENACAO_H_

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

#define MAX_CHAR_NOME 50

void getNome(char nome[]);

uint32_t getGRR();

ssize_t buscaSequencialRec(int vetor[], size_t tam, int valor,
                           uint64_t* numComparacoes);

ssize_t buscaSequencial(int vetor[], size_t tam, int valor,
                        uint64_t* numComparacoes);

ssize_t buscaBinariaRec(int vetor[], size_t tam, int valor,
                        uint64_t* numComparacoes);

ssize_t buscaBinaria(int vetor[], size_t tam, int valor,
                     uint64_t* numComparacoes);

uint64_t insertionSortRec(int vetor[], size_t tam);

uint64_t insertionSort(int vetor[], size_t tam);

uint64_t selectionSortRec(int vetor[], size_t tam);

uint64_t selectionSort(int vetor[], size_t tam);

uint64_t mergeSortRec(int vetor[], size_t tam);

uint64_t auxiliarbuscabin (int vetor[], ssize_t inicio, ssize_t fim, int valor, uint64_t* numComparacoes);

uint64_t auxiliarinssortrec (int vetor[], int fim, size_t tam, uint64_t *numcomp);

uint64_t auxiliarselecsortrec (int vetor[], int inicio, size_t tam, uint64_t *numcomp);

uint64_t auxiliarmergesort (int vetor[], int inicio, int fim, uint64_t *numcomp);

uint64_t merge (int vetor[], int inicio, int meio, int fim, uint64_t *numcomp);

void troca (int vetor[], int i);

void mostravetor (int vetor[], int tam);

void menu ();

#endif