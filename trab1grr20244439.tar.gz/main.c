#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <time.h>

#include "ordenacao.h"

int main() {
    char nome[MAX_CHAR_NOME];
    ssize_t idxBusca;
    ssize_t resultado;
    uint64_t numComp = 0;
    int escolha;
    
    clock_t start, end;  
    double total;
    // Inserir o tamanho que quero testar o vetor:
    ssize_t tamVetor = 100000;

    int* vetor = malloc(tamVetor * sizeof(int));

    if (vetor == NULL) {
        printf("Falha. Impossível alocar memoria.");
        return 1;
    }
    
    // Para vetor ordenado, vetor[i] = i
    // Para vetor descrescente, vetor[i] = tamVetor - i
    for (ssize_t i = 0; i < tamVetor; i++)
        vetor[i] = tamVetor - i;

    // Organizando os códigos em menu:
    printf ("\nAtualmente, o código está em ordem decrescente!"); // Alterar para fazer outros testes
    printf ("\nVoce esta testando um vetor de %ld elementos!\n", tamVetor);
    menu();
    scanf ("%d", &escolha);

    switch(escolha) {
    case 1:
    // Fazendo testes pela Busca Sequencial Iterativa:
    int valorbuscaseq;
    printf ("Digite o valor: ");
    scanf ("%d", &valorbuscaseq);
    start = clock();
    idxBusca = buscaSequencial (vetor, tamVetor, valorbuscaseq, &numComp);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nBusca Sequencial Iterativa");
    printf ("\nO valor deveria estar na posicao: %ld", idxBusca);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim da Busca Sequencial Iterativa.

    case 2:
    // Fazendo testes pela Busca Sequencial Recursiva:
    int valorbuscaseqrec;
    printf ("Digite o valor: ");
    scanf ("%d", &valorbuscaseqrec);
    start = clock();
    idxBusca = buscaSequencialRec (vetor, tamVetor, valorbuscaseqrec, &numComp);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nBusca Sequencial Recursiva");
    printf ("\nO valor deveria estar na posicao: %ld", idxBusca);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim da Busca Sequencial Recursiva.

    case 3:
    // Fazendo testes pela Busca Binária Iterativa:
    int valorbuscabin;
    printf ("Digite o valor: ");
    scanf ("%d", &valorbuscabin);
    start = clock();
    idxBusca = buscaBinaria (vetor, tamVetor, valorbuscabin, &numComp);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;
    
    printf ("\nBusca Binária Iterativa");
    printf ("\nO valor deveria estar na posicao: %ld", idxBusca);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim da Busca Binária Iterativa.

    case 4:
    // Fazendo testes pela Busca Binária Recursiva
    int valorbuscabinrec;
    printf ("Digite o valor: ");
    scanf ("%d", &valorbuscabinrec);
    start = clock();
    idxBusca = buscaBinariaRec (vetor, tamVetor, valorbuscabinrec, &numComp);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nBusca Binária Recursiva");
    printf ("\nO valor deveria estar na posicao: %ld", idxBusca);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim da Busca Binária Recursiva.

    case 5:
    // Fazendo teste pelo Insertion Sort Iterativo:
    start = clock();
    resultado = insertionSort (vetor, tamVetor);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nInsertion Sort Iterativo");
    printf ("\nO numero de comparacoes foi de: %ld", resultado);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim do Insertion Sort Iterativo.

    case 6:
    // Fazendo teste pelo Insertion Sort Recursivo:
    start = clock();
    resultado = insertionSortRec (vetor, tamVetor);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nInsertion Sort Recursivo");
    printf ("\nO numero de comparacoes foi de: %ld", resultado);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim do Insertion Sort Recursivo.

    case 7:
    // Fazendo teste pelo Selection Sort Iterativo:
    start = clock();
    resultado = selectionSort (vetor, tamVetor);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nSelection Sort Iterativo");
    printf ("\nO numero de comparacoes foi de: %ld", resultado);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim do Selection Sort Iterativo.

    case 8:
    // Fazendo teste pelo Selection Sort Recursivo:
    start = clock();
    resultado = selectionSortRec (vetor, tamVetor);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;

    printf ("\nSelection Sort Recursivo");
    printf ("\nO numero de comparacoes foi de: %ld", resultado);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim do Selection Sort Recursivo.

    case 9:
    // Fazendo teste pelo Merge Sort Recursivo:
    start = clock();
    resultado = mergeSortRec (vetor, tamVetor);
    end = clock();
    total = ((double)end - start) / CLOCKS_PER_SEC;
    
    printf ("\nMerge Sort Recursivo");
    printf ("\nO numero de comparacoes foi de: %ld", resultado);
    printf ("\nTempo total: %f\n", total);
    break;
    // Fim do Merge Sort Recursivo.

    case 0:
        return 0;
    }

    getNome(nome);
    printf("Trabalho de %s\n", nome);
    printf("GRR %u\n", getGRR());

    free(vetor);

    return 0;
}