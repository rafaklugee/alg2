#include "ordenacao.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void getNome(char nome[]) {
    strncpy(nome, "Rafael Ribeiro Kluge", MAX_CHAR_NOME);
    nome[MAX_CHAR_NOME - 1] =
        '\0';
}

uint32_t getGRR() { return 20244439; }

void mostravetor (int vetor[], int tam) {
    int i;
    printf ("O vetor eh:\t");
    for (i = 0; i < tam; i++) {
        printf ("%d\t", vetor[i]);
    }
}

ssize_t buscaSequencial(int vetor[], size_t tam, int valor,
                        uint64_t* numComparacoes) {
    int i;
    for (i = tam-1; i >= 0; i--) {
        (*numComparacoes)++;
        if (vetor[i] < valor)
            return i + 1;
    }
    return i;
}

ssize_t buscaSequencialRec(int vetor[], size_t tam, int valor,
                           uint64_t* numComparacoes) {
        if (tam == 0) {
            return -1;
        }
        (*numComparacoes)++;
        if (vetor[tam-1] <= valor) {
            return tam - 1;
        }
        return buscaSequencialRec(vetor, tam-1, valor, numComparacoes);
}

ssize_t buscaBinaria(int vetor[], size_t tam, int valor,
                     uint64_t* numComparacoes) {
        ssize_t inicio = 0;
        ssize_t fim = tam - 1;
        while (inicio <= fim) {
            (*numComparacoes)++;
            ssize_t meio = (inicio + fim)/2;
            if (vetor[meio] == valor)
                return meio;

            if (vetor[meio] > valor)
                fim = meio - 1;

            if (vetor[meio] < valor)
                inicio = meio + 1;
        }   
    return inicio;
}

uint64_t auxiliarbuscabin (int vetor[], ssize_t inicio, ssize_t fim, int valor, uint64_t* numComparacoes) {
    while (inicio <= fim) {
        (*numComparacoes)++;
        ssize_t meio = (inicio + fim)/2;
        if (vetor[meio] == valor)
            return meio;

        if (vetor[meio] > valor)
            return auxiliarbuscabin (vetor, inicio, meio - 1, valor, numComparacoes);

        if (vetor[meio] < valor)
            return auxiliarbuscabin (vetor, meio + 1, fim, valor, numComparacoes);
    }
    return inicio;
}

ssize_t buscaBinariaRec(int vetor[], size_t tam, int valor,
                        uint64_t* numComparacoes) {
        return auxiliarbuscabin (vetor, 0, tam - 1, valor, numComparacoes);
}

void troca (int vetor[], int i) {
    int temp;
    temp = vetor[i];
    vetor[i] = vetor[i + 1];
    vetor[i + 1] = temp; 
}

uint64_t insertionSort(int vetor[], size_t tam) {
    int i, j;                                    
    uint64_t numcomp = 0;
    for (i = 0; i < tam - 1; i++) {
        j = i;
        while ((j >= 0) && vetor[j] > vetor[j + 1]) {
                numcomp++;
                troca (vetor, j);
                j--;
        }
    }
    return numcomp;
}

uint64_t auxiliarinssortrec (int vetor[], int fim, size_t tam, uint64_t *numcomp) {
    int j = fim, temp = vetor[j];
    if (fim >= tam) {
        return (*numcomp);
    }
    while (j > 0 && temp < vetor[j - 1]) {
        (*numcomp)++;
        vetor[j] = vetor[j - 1];
        j--;
    }
    vetor[j] = temp;
    return auxiliarinssortrec (vetor, fim + 1, tam, numcomp);
    
}

uint64_t insertionSortRec(int vetor[], size_t tam) {
    uint64_t numcompaux = 0;
    return auxiliarinssortrec (vetor, 1, tam, &numcompaux);
}

uint64_t selectionSort(int vetor[], size_t tam) { 
    int i, j, idxmenor, temp;
    uint64_t numcomp = 0;
    for (i = 0; i < tam - 1; i++) {
        idxmenor = i;
        for (j = i + 1; j < tam; j++) {
            numcomp++;
            if (vetor[idxmenor] > vetor[j])
                idxmenor = j;
        }
        if (i != idxmenor) {
            temp = vetor[i];
            vetor[i] = vetor[idxmenor];                
            vetor[idxmenor] = temp;
            }
        }
        return numcomp;
}

uint64_t auxiliarselecsortrec (int vetor[], int inicio, size_t tam, uint64_t *numcomp) {
    int i, temp, idxmenor = inicio;                               
    if (inicio >= tam - 1) {                              
        return (*numcomp);
    }
    for (i = inicio + 1; i < tam; i++) {
        (*numcomp)++;
        if (vetor[i] < vetor[idxmenor])
            idxmenor = i;
    }
        temp = vetor[inicio];
        vetor[inicio] = vetor[idxmenor];
        vetor[idxmenor] = temp;

    return auxiliarselecsortrec (vetor, inicio + 1, tam, numcomp);
}

uint64_t selectionSortRec(int vetor[], size_t tam) {
    uint64_t numcompaux = 0;
    return auxiliarselecsortrec (vetor, 0, tam, &numcompaux);
}

uint64_t merge (int vetor[], int inicio, int meio, int fim, uint64_t *numcomp) {
    int i, j, inicio1 = inicio, inicio2 = meio + 1, fim1 = meio, fim2 = fim; 
    int tamaux = (fim - inicio) + 1;
    int *vaux = malloc (tamaux * sizeof(int));
    uint64_t numcompmerge = 0;
    if (vaux != NULL) {
        for (i = 0; i < tamaux; i++) {
            numcompmerge++;
            if (inicio1 <= fim1 && inicio2 <= fim2) {
                if (vetor[inicio1] < vetor[inicio2]) {
                    vaux[i] = vetor[inicio1];
                    inicio1++;
                }
                else {
                    vaux[i] = vetor[inicio2];
                    inicio2++;
                }
            }
            else {
                if (inicio1 <= meio) {
                    vaux[i] = vetor[inicio1];
                    inicio1++;
                }
                else {
                    vaux[i] = vetor[inicio2];
                    inicio2++;
                }
            }
        }
        (*numcomp) += numcompmerge;
        for (j = 0; j < tamaux; j++) {
            vetor[inicio] = vaux[j];
            inicio++;
        }
    }
    free (vaux);
    return numcompmerge;
}


uint64_t auxiliarmergesort (int vetor[], int inicio, int fim, uint64_t *numcomp) {
    int meio;
    uint64_t numcompaux = 0;
    if (inicio < fim) {
        meio = (inicio + fim)/2;
        numcompaux += auxiliarmergesort (vetor, inicio, meio, numcomp);
        numcompaux += auxiliarmergesort (vetor, meio + 1, fim, numcomp);
        numcompaux += merge (vetor, inicio, meio, fim, numcomp);
    }
    return numcompaux;
}

uint64_t mergeSortRec (int vetor[], size_t tam) {
    uint64_t numcomp = 0;
    return auxiliarmergesort (vetor, 0, tam - 1, &numcomp);
}

void menu () {
    printf ("(1) Busca Sequencial iterativa\n");
    printf ("(2) Busca sequencial recursiva\n");
    printf ("(3) Busca Binaria iterativa\n");
    printf ("(4) Busca Binaria recursiva\n");
    printf ("(5) Insertion Sort iterativo\n");
    printf ("(6) Insertion Sort recursivo\n");
    printf ("(7) Selection Sort iterativo\n");
    printf ("(8) Selection Sort recursivo\n");
    printf ("(9) Merge Sort recursivo\n");
    printf ("(0) Sair do programa\n");
    printf ("Escolha uma opcao: ");
}